import React from 'react'
import { Routes, Route } from 'react-router'
import Home from './pages/Home'
import Collection from './pages/Collection'
import About from './pages/About'
import Contact from './pages/Contact'
import Product from './pages/Product'
import Cart from './pages/Cart'
import Login from './pages/Login'
import PlaceOrder from './pages/PlaceOrder'
import Order from './pages/Order'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Search from './components/Search'
import ScrollTop from './components/ScrollTop'
import PageTransition from './components/PageTransition'
import { ToastContainer } from 'react-toastify'
import Verify from './pages/Verify'

const App = () => {
  return (
    <div className='px-4 sm:px-[5vw] md:px-[7vw] lg:px-[9vw] bg-[#F9F6F0] min-h-screen'>
      <ToastContainer
        toastClassName='jost text-sm'
        position='top-right'
        autoClose={3000}
        hideProgressBar={false}
        closeOnClick
        pauseOnHover
        draggable
      />
      <Navbar />
      <Search />
      <ScrollTop />
      <PageTransition>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/home' element={<Home />} />
          <Route path='/collection' element={<Collection />} />
          <Route path='/about' element={<About />} />
          <Route path='/contact' element={<Contact />} />
          <Route path='/product/:productId' element={<Product />} />
          <Route path='/cart' element={<Cart />} />
          <Route path='/login' element={<Login />} />
          <Route path='/place-order' element={<PlaceOrder />} />
          <Route path='/orders' element={<Order />} />
          <Route path='/verify' element={<Verify />} />
        </Routes>
      </PageTransition>
      <Footer />
    </div>
  )
}

export default App
