import React, { useContext, useEffect, useState, useRef } from "react";
import { ShopContext } from "../context/Shop";
import ProductItem from "../components/ProductItem";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const Collection = () => {
  const { products, search, showSearch } = useContext(ShopContext);
  const [filterProducts, setFilterProducts] = useState([]);
  const [category, setCategory] = useState([]);
  const [subCategory, setSubCategory] = useState([]);
  const [sortType, setSortType] = useState("relevant");

  const headerRef = useRef(null);
  const filtersRef = useRef(null);
  const gridRef = useRef(null);
  const sidebarRef = useRef(null);

  const toggleCategory = (val) => {
    setCategory((prev) =>
      prev.includes(val) ? prev.filter((i) => i !== val) : [...prev, val]
    );
  };

  const toggleSubCategory = (val) => {
    setSubCategory((prev) =>
      prev.includes(val) ? prev.filter((i) => i !== val) : [...prev, val]
    );
  };

  useEffect(() => {
    let productsCopy = products.slice();
    if (showSearch && search) {
      productsCopy = productsCopy.filter((item) =>
        item.name.toLowerCase().includes(search.toLowerCase())
      );
    }
    if (category.length > 0) {
      productsCopy = productsCopy.filter((item) =>
        category.includes(item.category)
      );
    }
    if (subCategory.length > 0) {
      productsCopy = productsCopy.filter((item) =>
        subCategory.includes(item.subCategory)
      );
    }
    switch (sortType) {
      case "low-high":
        productsCopy.sort((a, b) => a.price - b.price);
        break;
      case "high-low":
        productsCopy.sort((a, b) => b.price - a.price);
        break;
      default:
        break;
    }
    setFilterProducts(productsCopy);
  }, [products, search, showSearch, category, subCategory, sortType]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        headerRef.current,
        { opacity: 0, y: -30 },
        { opacity: 1, y: 0, duration: 0.8, ease: "power3.out" }
      );
      gsap.fromTo(
        sidebarRef.current,
        { opacity: 0, x: -40 },
        { opacity: 1, x: 0, duration: 0.7, delay: 0.2, ease: "power3.out" }
      );
      const pills = filtersRef.current?.querySelectorAll(".filter-pill");
      if (pills?.length) {
        gsap.fromTo(
          pills,
          { opacity: 0, y: 20, scale: 0.9 },
          { opacity: 1, y: 0, scale: 1, duration: 0.5, stagger: 0.07, delay: 0.3, ease: "back.out(1.7)" }
        );
      }
    });
    return () => ctx.revert();
  }, []);

  useEffect(() => {
    if (!gridRef.current) return;
    const cards = gridRef.current.querySelectorAll(".product-card");
    gsap.fromTo(
      cards,
      { opacity: 0, y: 30, scale: 0.95 },
      { opacity: 1, y: 0, scale: 1, duration: 0.45, stagger: 0.04, ease: "power2.out" }
    );
  }, [filterProducts]);

  const activeFilterCount = category.length + subCategory.length;

  return (
    <div className="min-h-screen bg-[#111111] -mx-4 sm:-mx-[5vw] md:-mx-[7vw] lg:-mx-[9vw]">
      {/* Header */}
      <div
        ref={headerRef}
        className="px-4 sm:px-[5vw] md:px-[7vw] lg:px-[9vw] pt-14 pb-8 border-b border-white/10"
      >
        <p className="text-[10px] tracking-[0.35em] text-white/40 uppercase mb-3 font-light">
          Discover
        </p>
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
          <div>
            <h1 className="text-5xl sm:text-6xl font-bold leading-none">
              <span className="text-white">All </span>
              <span className="text-white/25">Collection</span>
            </h1>
            <p className="text-white/40 text-sm mt-3 font-light">
              {filterProducts.length} items
            </p>
          </div>
          <select
            onChange={(e) => setSortType(e.target.value)}
            className="bg-white/5 border border-white/15 text-white/70 text-sm px-5 py-2.5 rounded-full cursor-pointer hover:border-white/30 hover:bg-white/10 transition-all duration-200 focus:outline-none focus:border-white/40"
          >
            <option value="relevant" className="bg-[#1a1a1a]">Sort: Relevant</option>
            <option value="low-high" className="bg-[#1a1a1a]">Sort: Low to High</option>
            <option value="high-low" className="bg-[#1a1a1a]">Sort: High to Low</option>
          </select>
        </div>

        <div className="mt-8 h-px bg-white/10" />

        {/* Filter Pills */}
        <div ref={filtersRef} className="flex flex-wrap items-center gap-2 mt-6">
          <span className="text-[10px] tracking-[0.3em] text-white/30 uppercase mr-2 font-light">Filter</span>
          <div className="w-px h-4 bg-white/15" />
          {["Men", "Women", "Kids"].map((cat) => (
            <button
              key={cat}
              onClick={() => toggleCategory(cat)}
              className={`filter-pill px-4 py-1.5 rounded-full text-xs font-medium tracking-wide border transition-all duration-200 ${
                category.includes(cat)
                  ? "bg-white text-black border-white"
                  : "bg-transparent text-white/60 border-white/20 hover:border-white/50 hover:text-white/90"
              }`}
            >
              {cat}
            </button>
          ))}
          <div className="w-px h-4 bg-white/15 mx-1" />
          {["Topwear", "Bottomwear", "Winterwear"].map((sub) => (
            <button
              key={sub}
              onClick={() => toggleSubCategory(sub)}
              className={`filter-pill px-4 py-1.5 rounded-full text-xs font-medium tracking-wide border transition-all duration-200 ${
                subCategory.includes(sub)
                  ? "bg-white text-black border-white"
                  : "bg-transparent text-white/60 border-white/20 hover:border-white/50 hover:text-white/90"
              }`}
            >
              {sub}
            </button>
          ))}
          {activeFilterCount > 0 && (
            <button
              onClick={() => { setCategory([]); setSubCategory([]); }}
              className="filter-pill ml-2 px-3 py-1.5 rounded-full text-xs text-white/40 border border-white/10 hover:text-white/70 hover:border-white/30 transition-all duration-200"
            >
              Clear ({activeFilterCount})
            </button>
          )}
        </div>
      </div>

      {/* Body */}
      <div className="flex flex-col sm:flex-row gap-0">
        {/* Sidebar */}
        <div
          ref={sidebarRef}
          className="hidden lg:block w-56 shrink-0 border-r border-white/10 px-6 pt-10"
        >
          <p className="text-[10px] tracking-[0.3em] text-white/30 uppercase mb-5 font-light">Categories</p>
          <div className="flex flex-col gap-3 mb-10">
            {["Men", "Women", "Kids"].map((cat) => (
              <label key={cat} className="flex items-center gap-3 cursor-pointer group" onClick={() => toggleCategory(cat)}>
                <div className={`w-3.5 h-3.5 rounded-sm border transition-all duration-150 flex items-center justify-center shrink-0 ${category.includes(cat) ? "bg-white border-white" : "border-white/25 group-hover:border-white/50"}`}>
                  {category.includes(cat) && (
                    <svg className="w-2.5 h-2.5" viewBox="0 0 10 10" fill="none">
                      <path d="M1.5 5L4 7.5L8.5 2.5" stroke="#111" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </div>
                <span className={`text-sm transition-colors duration-150 ${category.includes(cat) ? "text-white" : "text-white/50 group-hover:text-white/80"}`}>{cat}</span>
              </label>
            ))}
          </div>
          <p className="text-[10px] tracking-[0.3em] text-white/30 uppercase mb-5 font-light">Type</p>
          <div className="flex flex-col gap-3">
            {["Topwear", "Bottomwear", "Winterwear"].map((sub) => (
              <label key={sub} className="flex items-center gap-3 cursor-pointer group" onClick={() => toggleSubCategory(sub)}>
                <div className={`w-3.5 h-3.5 rounded-sm border transition-all duration-150 flex items-center justify-center shrink-0 ${subCategory.includes(sub) ? "bg-white border-white" : "border-white/25 group-hover:border-white/50"}`}>
                  {subCategory.includes(sub) && (
                    <svg className="w-2.5 h-2.5" viewBox="0 0 10 10" fill="none">
                      <path d="M1.5 5L4 7.5L8.5 2.5" stroke="#111" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </div>
                <span className={`text-sm transition-colors duration-150 ${subCategory.includes(sub) ? "text-white" : "text-white/50 group-hover:text-white/80"}`}>{sub}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        <div className="flex-1 px-4 sm:px-[5vw] md:px-[7vw] lg:px-8 py-10">
          <div
            ref={gridRef}
            className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 gap-y-8"
          >
            {filterProducts.map((item, index) => (
              <div key={index} className="product-card">
                <ProductItem
                  id={item._id}
                  image={item.image}
                  name={item.name}
                  price={item.price}
                  dark={true}
                />
              </div>
            ))}
          </div>

          {filterProducts.length === 0 && (
            <div className="flex flex-col items-center justify-center py-32 text-center">
              <p className="text-white/20 text-6xl mb-4">∅</p>
              <p className="text-white/40 text-sm tracking-widest uppercase">No items found</p>
              <button
                onClick={() => { setCategory([]); setSubCategory([]); }}
                className="mt-6 px-6 py-2 border border-white/20 text-white/50 text-xs tracking-widest uppercase rounded-full hover:border-white/50 hover:text-white/80 transition-all duration-200"
              >
                Clear Filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Collection;
