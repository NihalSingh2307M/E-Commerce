import express from 'express'
import cors from 'cors'
import 'dotenv/config'
import connectDb from './config/mongodb.js'
import connectCloudinary from './config/cloudinary.js'
import userRouter from './routes/userRoute.js'
import productRouter from './routes/productRoute.js'
import cartRouter from './routes/cartRoute.js'
import orderRouter from './routes/orderRoute.js'
import chatRouter from './routes/chatRoute.js'
import searchRouter from './vector-search/routes/searchRoute.js'

//-------app config---
const app = express()
const port = process.env.PORT || 4000
connectDb()
connectCloudinary()

//------middle ware--------
app.use(express.json())
app.use(cors())

//-----api endpoints----
app.use('/api/user',userRouter)
app.use('/api/product',productRouter)
app.use('/api/cart',cartRouter)
app.use('/api/order',orderRouter)
app.use('/api/chat',chatRouter)
app.use('/api/search',  searchRouter)

app.get('/',(req,res)=>
    {
        res.send("API is working")
    })

app.listen(port,()=> console.log('server started on PORT:'+port))